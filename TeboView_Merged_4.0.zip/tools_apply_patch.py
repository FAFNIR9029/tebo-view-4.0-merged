#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Tebo-View 破解补丁工具（32 位；Tebo-IctView.exe / Tebo-JTD.exe 同代码布局通用）

作用（3 处跳转，共 6 字节）：
  1) 跳过「没有权限打开该[客户ID：xxx]文件！」的授权比较 —— 任何客户的 .tvw 都能开
  2) 跳过 .tvw 文件密码输入框 —— 有密码的文件不再询问，直接读取
  3) 跳过「文件版本太新，请升级」的中断 —— 新版本号的文件仍交给本程序解析

用法：
  python tools_apply_patch.py <原始 exe> <输出 exe>
  python tools_apply_patch.py --verify <已破解 exe>

补丁点（ImageBase=0x400000，.text 段 VA == 文件偏移）：
  0x001c7f  75 12                 -> eb 12                jne -> jmp
  0x001d1f  74 77                 -> eb 77                je  -> jmp
  0x001dd0  0f 84 a7 00 00 00     -> e9 a8 00 00 00 90    je  -> jmp 0x401e7d
说明：第 3 处原 je 为 6 字节，换成 5 字节 E9 后位移要按新指令结尾(0x401dd5)重算，
      故 rel 由 0xA7 改为 0xA8，末字节补 90。照抄 0xA7 会落到 0x401e7c 指令中间而崩溃。
"""

import sys, os, hashlib

# (名称, 定位特征, 特征内偏移, 原字节, 新字节, 说明)
PATCHES = [
    ("skip_version_abort",
     bytes.fromhex("85c07512 6aff 50 68 3bf00000"),
     2, bytes.fromhex("7512"), bytes.fromhex("eb12"),
     "文件版本比程序新时不再中断"),
    ("skip_customer_license",
     bytes.fromhex("85c07477 8d4c2420"),
     2, bytes.fromhex("7477"), bytes.fromhex("eb77"),
     "跳过 [客户ID] 授权比较"),
    ("skip_password_dialog",
     bytes.fromhex("85c00f84a7000000 6a00"),
     2, bytes.fromhex("0f84a7000000"), bytes.fromhex("e9a800000090"),
     "跳过 .tvw 密码框"),
]


def sha256(b):
    return hashlib.sha256(b).hexdigest()


def patched_sig(sig, off, old, new):
    return sig[:off] + new + sig[off + len(old):]


def apply(data):
    data = bytearray(data)
    done = []
    for name, sig, off, old, new, note in PATCHES:
        if bytes(data[data.find(patched_sig(sig, off, old, new)):][:1]) and data.find(sig) < 0:
            done.append((name, -1, old.hex(), new.hex(), "已是补丁状态，跳过"))
            continue
        idx = data.find(sig)
        if idx < 0:
            raise SystemExit("[!] 找不到特征 %s，文件不是同一代版本" % name)
        if data.find(sig, idx + 1) >= 0:
            raise SystemExit("[!] 特征 %s 命中多次，拒绝盲改" % name)
        pos = idx + off
        cur = bytes(data[pos:pos + len(old)])
        if cur != old:
            raise SystemExit("[!] %s 处字节不符：%s" % (name, cur.hex()))
        data[pos:pos + len(new)] = new
        done.append((name, pos, old.hex(), new.hex(), note))
    return bytes(data), done


def verify(data):
    ok = True
    for name, sig, off, old, new, note in PATCHES:
        ps = patched_sig(sig, off, old, new)
        n_new = data.count(ps)
        n_old = data.count(sig)
        state = "PATCHED" if n_new == 1 and n_old == 0 else ("ORIGINAL" if n_old == 1 and n_new == 0 else "UNCLEAR")
        if state != "PATCHED":
            ok = False
        print("  %-24s %-9s (原特征 %d 处, 补丁后特征 %d 处)" % (name, state, n_old, n_new))
    print("  结论:", "已全部打好补丁" if ok else "未完全打补丁")
    print("  sha256 =", sha256(data), " size =", len(data))
    return ok


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    if argv[0] == "--verify":
        return 0 if verify(open(argv[1], 'rb').read()) else 2
    if len(argv) < 2:
        print("用法: python tools_apply_patch.py <原始 exe> <输出 exe>")
        return 1
    src, dst = argv[0], argv[1]
    raw = open(src, 'rb').read()
    out, done = apply(raw)
    tmp = dst + ".tmp"
    with open(tmp, 'wb') as f:
        f.write(out)
    if os.path.exists(dst):
        try:
            os.remove(dst)
        except OSError:
            pass
    os.replace(tmp, dst)
    diff = sum(1 for a, b in zip(raw, out) if a != b)
    print("源文件 :", src)
    print("  sha256 %s  size %d" % (sha256(raw), len(raw)))
    print("输出   :", dst)
    print("  sha256 %s  size %d  差异 %d 字节" % (sha256(out), len(out), diff))
    for name, pos, old, new, note in done:
        loc = ("%#08x" % pos) if pos >= 0 else "(已打过)"
        print("  [%s] %s -> %s   %s: %s" % (loc, old, new, name, note))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
