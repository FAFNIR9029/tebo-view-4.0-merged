#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
读取 Tebo-View .tvw 头部信息：魔术串 / 数据版本 / 客户ID / 文件密码 / 保存日期。

原理：头部字符串用 BaseTool.dll!IBaseTool::DeEncryptString 的字符置换保存，
      置换与密码无关（按字符类别 + 位置位移），逆变换即可还原明文。
      正文数据并未用密码加密，密码只是打开时的一道比对。

用法：
    python tools_tvw_info.py a.tvw b.tvw ...
    python tools_tvw_info.py "D:\tvw目录"      # 目录里所有 .tvw
"""

import struct, sys, os, glob


def decrypt(b):
    out = bytearray()
    for i, c in enumerate(b):
        if 0x6b <= c <= 0x7a:                     # k-z
            v = (c + (0xFB - i % 10)) & 0xFF
            if v < 0x6b:
                v = (v + 0x10) & 0xFF
        elif 0x41 <= c <= 0x5a:                   # A-Z
            v = (c + (i % 10) + 5) & 0xFF
            if v > 0x5a:
                v = (v + 0xE6) & 0xFF
        elif 0x30 <= c <= 0x39:                   # 0-9
            v = (c + (i % 3) + 4) & 0xFF
            if v > 0x39:
                v = (v + 0xF6) & 0xFF
            v = (v + 0x31) & 0xFF
        elif 0x61 <= c <= 0x6a:                   # a-j
            v = (c + (0xFC - i % 3)) & 0xFF
            if v < 0x61:
                v = (v + 0x0A) & 0xFF
            v = (0x9A - v) & 0xFF
        else:
            v = c
        out.append(v)
    return bytes(out)


def read_cstr(d, off):
    n = d[off]
    if n == 0xFF:
        n = struct.unpack_from('<H', d, off + 1)[0]
        off += 3
    else:
        off += 1
    return d[off:off + n], off + n


def info(path):
    d = open(path, 'rb').read()
    off = 0
    magic, off = read_cstr(d, off)
    ver = struct.unpack_from('<I', d, off)[0]
    off += 4
    cust, off = read_cstr(d, off)
    pwd, off = read_cstr(d, off)
    extra = []
    try:
        for _ in range(4):
            s, off = read_cstr(d, off)
            extra.append(decrypt(s).decode('gbk', 'replace'))
    except Exception:
        pass

    def dec(x):
        return decrypt(x).decode('gbk', 'replace')

    return dict(file=path, size=len(d), magic=dec(magic), ver=ver,
                cust=dec(cust), pwd=dec(pwd), extra=extra)


def main(argv):
    targets = []
    for a in argv:
        if os.path.isdir(a):
            targets += sorted(glob.glob(os.path.join(a, '*.tvw')) +
                              glob.glob(os.path.join(a, '*.TVW')))
        else:
            targets.append(a)
    if not targets:
        print(__doc__)
        return 1
    for t in targets:
        try:
            r = info(t)
        except Exception as e:
            print("%s: 读取失败 %s" % (os.path.basename(t), e))
            continue
        print(os.path.basename(t))
        print("    大小 %s   版本 %s   客户ID %r   密码 %r" %
              (format(r['size'], ','), r['ver'], r['cust'], r['pwd']))
        print("    魔术 %r   附加 %s" % (r['magic'], [x for x in r['extra'] if x]))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
